var  city1  =  {
    Название : "Константинополь" ,
    Население : 100000000 ,
    GetName : function ( ) { console . log ( this . name ) } ,
    exportStr : function ( ) { console . журнал ( это . имя , это . население ) }
} ;

var  city2  =  {
    Название : "Еленендорф" ,
    Население : 10 ^ 6 ,
    GetName : function ( ) { console . log ( this . name ) } ,
    exportStr : function ( ) { console . журнал ( это . имя , это . население ) }
} ;

город1 . test = "tdjp" ;